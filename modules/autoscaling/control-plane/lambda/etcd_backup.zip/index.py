import boto3
import os

def handler(event, context):
    ssm = boto3.client('ssm')
    cluster_name = os.environ['CLUSTER_NAME']
    
    response = ssm.send_command(
        Targets=[{
            'Key': 'tag:kubernetes.io/role',
            'Values': ['control-plane']
        }],
        DocumentName='AWS-RunShellScript',
        Parameters={
            'commands': ['/etc/kubernetes/etcd-backup.sh'],
            'workingDirectory': ['/'],
            'executionTimeout': ['3600']
        },
        TimeoutSeconds=600,
        MaxConcurrency='1',
        MaxErrors='0'
    )
    return response
